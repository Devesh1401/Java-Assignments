package com.in28minutes.jpa.hibernate.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Student {
	@Id
	private int studId;
	@Column
	private String studName;
	@Column
	private int studMarks;
	@ManyToOne
	private Course course; 
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Student(int studId, String studName, int studMarks, Course course) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.studMarks = studMarks;
		this.course = course;
	}


	public int getStudId() {
		return studId;
	}


	public void setStudId(int studId) {
		this.studId = studId;
	}


	public String getStudName() {
		return studName;
	}


	public void setStudName(String studName) {
		this.studName = studName;
	}


	public int getStudMarks() {
		return studMarks;
	}


	public void setStudMarks(int studMarks) {
		this.studMarks = studMarks;
	}


	public Course getCourse() {
		return course;
	}


	public void setCourse(Course course) {
		this.course = course;
	}


	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", studMarks=" + studMarks + ", course="
				+ course + "]";
	}

	
	
	
}
