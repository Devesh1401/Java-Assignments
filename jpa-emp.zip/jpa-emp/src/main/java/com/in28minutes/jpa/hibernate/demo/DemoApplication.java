package com.in28minutes.jpa.hibernate.demo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.in28minutes.jpa.hibernate.demo.entity.Book;
import com.in28minutes.jpa.hibernate.demo.entity.Course;
import com.in28minutes.jpa.hibernate.demo.entity.Customer;
import com.in28minutes.jpa.hibernate.demo.entity.Employee;
import com.in28minutes.jpa.hibernate.demo.entity.Library;
import com.in28minutes.jpa.hibernate.demo.entity.Passport;
import com.in28minutes.jpa.hibernate.demo.entity.Student;
import com.in28minutes.jpa.hibernate.demo.entity.Ticket;
import com.in28minutes.jpa.hibernate.demo.repository.BookRepository;
import com.in28minutes.jpa.hibernate.demo.repository.CourseRepository;
import com.in28minutes.jpa.hibernate.demo.repository.CustomerRepository;
import com.in28minutes.jpa.hibernate.demo.repository.EmployeeRepository;
import com.in28minutes.jpa.hibernate.demo.repository.LibraryRepository;
import com.in28minutes.jpa.hibernate.demo.repository.PassportRepository;
import com.in28minutes.jpa.hibernate.demo.repository.StudentRepository;
import com.in28minutes.jpa.hibernate.demo.repository.TicketRepository;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private PassportRepository passportRepository;
	
	@Autowired
	private TicketRepository ticketRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private CourseRepository courseRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private LibraryRepository libraryRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		
		Library lib = new Library(200,"abc");
		Library lib1 = new Library(201,"xyz");
		libraryRepository.insert(lib);
		libraryRepository.insert(lib1);
		List<Library> ls = new ArrayList<Library>();
		ls.add(lib);
		ls.add(lib1);
		
		Book b = new Book(400,"Physics");
		b.setLibraries(ls);
		bookRepository.insert(b);
		
		Course course = new Course(1001,"Spring");
		Course course1 = new Course(1002,"Java");
		courseRepository.insert(course);
		courseRepository.insert(course1);
		
		Student st = new Student(20,"Smith",500,course);
		Student st1 = new Student(21,"Stoinis",400,course1);
		studentRepository.save(st);
		studentRepository.save(st1);
		
		Ticket t = new Ticket(101,"RRR");
		Ticket t1 = new Ticket(102,"Bullet Train");
		ticketRepository.insert(t);
		ticketRepository.insert(t1);
		
		Customer c = new Customer("Ben",t);
		Customer c1 = new Customer("James",t1);
		customerRepository.insert(c);
		customerRepository.insert(c1);
		
		Ticket t3 = ticketRepository.findById(101);
		System.out.println(t3.getCustomer().getCustomerName());
		
		Passport p = new Passport("101",LocalDate.now());
		Passport p1 = new Passport("102",LocalDate.now());
		passportRepository.insert(p);
		passportRepository.insert(p1);
		
		Employee e = new Employee("Harry",8000,p);
		Employee e1 = new Employee("Brook",4000,p1);
	//	System.out.println("before persisting for e: "+e);
	//	System.out.println("before persisting for e1: "+e1);
		employeeRepository.insert(e);
		employeeRepository.insert(e1);
		
//		Employee ex = employeeRepository.findById(1L);
//		System.out.println("retrieve back before merging: "+ex);
//		
//		ex.setSalary(60000);
//		System.out.println("retrieve back before merging and change salaray: "+ex);
//		
//		employeeRepository.save(ex);
//		logger.info("Full Time Employees -> {}", employeeRepository.retrieveEmployees());
//
//		employeeRepository.deleteById(2L);
//		

	}
}