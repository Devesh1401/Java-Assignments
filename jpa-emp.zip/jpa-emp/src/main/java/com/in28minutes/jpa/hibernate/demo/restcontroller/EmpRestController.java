package com.in28minutes.jpa.hibernate.demo.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.in28minutes.jpa.hibernate.demo.entity.Employee;
import com.in28minutes.jpa.hibernate.demo.repository.EmployeeRepository;

@RestController
public class EmpRestController {

	@Autowired
	EmployeeRepository employeeRepository;
	
	@PostMapping("/emp")
	public String addEmp(@RequestBody String name) {
		employeeRepository.insert(new Employee(name,2000));
		return "Emp Added Successfully";
	}
	
}
