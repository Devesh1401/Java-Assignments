package com.in28minutes.jpa.hibernate.demo.repository;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.in28minutes.jpa.hibernate.demo.entity.Customer;

@Repository
@Transactional
public class CustomerRepository {
	
	@Autowired
	EntityManager em;
	
	public void insert(Customer customer) {
		em.persist(customer);
	}
	
	public Customer findById(int id) {
		return em.find(Customer.class, id);
	}

}
